<?php
/**
 * database/class-market-install.php
 *
 * Thin activation / deactivation / uninstall wrapper.
 * The real schema logic lives in includes/class-market-db.php.
 *
 * Usage in your main plugin file:
 *   register_activation_hook( __FILE__, [ 'NEXORA_MARKET_INSTALL', 'activate' ] );
 *   register_deactivation_hook( __FILE__, [ 'NEXORA_MARKET_INSTALL', 'deactivate' ] );
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class NEXORA_MARKET_INSTALL {

    /**
     * Run on plugin activation.
     * Flushes rewrite rules so the webhook REST route is immediately available.
     */
    public static function activate(): void {
        NEXORA_MARKET_DB::install();
        flush_rewrite_rules();
    }

    /**
     * Run on plugin deactivation.
     * Does NOT drop tables — data must survive deactivate/reactivate cycles.
     */
    public static function deactivate(): void {
        self::clear_crons();
        flush_rewrite_rules();
    }

    /**
     * Run on full uninstall (called from uninstall.php, not deactivation).
     * Drops all tables and clears all options.
     */
    public static function uninstall(): void {
        self::clear_crons();
        NEXORA_MARKET_DB::uninstall();
        delete_option( 'nexora_market_db_version' );
        delete_option( 'nx_market_fee_pct' );
    }

    /* ── Private ──────────────────────────────────────────── */

    private static function clear_crons(): void {
        $table = $GLOBALS['wpdb']->prefix . 'nx_api_sources';
        if ( ! NEXORA_MARKET_DB::table_exists( $table ) ) return;

        $source_ids = $GLOBALS['wpdb']->get_col( "SELECT id FROM {$table}" );
        foreach ( (array) $source_ids as $id ) {
            NEXORA_MARKET_HELPER::unschedule_api_sync( (int) $id );
        }
    }
}
