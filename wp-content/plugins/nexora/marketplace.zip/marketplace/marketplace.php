<?php
/**
 * marketplace/marketplace.php
 *
 * Single include point for the entire Marketplace module.
 *
 *   require_once NEXORA_PATH . 'marketplace/marketplace.php';
 *
 * Class load order (dependency-safe):
 *   DB          → schema only, no deps
 *   Helper      → pure static utilities
 *   CSV         → depends on Helper
 *   API         → depends on Helper, WooCommerce
 *   Upload      → depends on Helper (wp.media sideloading)
 *   WooCommerce → depends on Helper
 *   Product     → depends on Helper, WooCommerce, DB
 *   Ajax        → depends on all of the above
 *   Core        → depends on all of the above
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ── Module constants ──────────────────────────────────────────── */
define( 'NEXORA_MARKETPLACE_PATH',      plugin_dir_path( __FILE__ ) );
define( 'NEXORA_MARKETPLACE_URL',       plugin_dir_url( __FILE__ ) );
define( 'NEXORA_MARKETPLACE_TEMPLATES', NEXORA_MARKETPLACE_PATH . 'templates/' );
define( 'NEXORA_MARKETPLACE_VERSION',   '2.0.0' );

/* ── Autoload classes ──────────────────────────────────────────── */
require_once NEXORA_MARKETPLACE_PATH . 'database/class-market-install.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-db.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-helper.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-csv.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-api.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-upload.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-woocommerce.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-product.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-ajax.php';
require_once NEXORA_MARKETPLACE_PATH . 'includes/class-market-core.php';

/* ── DB install / upgrade ─────────────────────────────────────── */
add_action( 'plugins_loaded', [ 'NEXORA_MARKET_DB', 'install' ], 5 );

/* ── Boot at priority 20 — after WooCommerce (priority 10) ───── */
add_action( 'plugins_loaded', 'nexora_marketplace_init', 20 );

function nexora_marketplace_init() {
    new NEXORA_MARKET_CORE();
    new NEXORA_MARKET_AJAX();
}

/* ── Activation / deactivation hooks ─────────────────────────── */
register_activation_hook( __FILE__, [ 'NEXORA_MARKET_INSTALL', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'NEXORA_MARKET_INSTALL', 'deactivate' ] );

/* ── CSV template download endpoint ──────────────────────────── */
add_action( 'wp_ajax_nexora_market_csv_template', function () {
    check_ajax_referer( 'nexora_market_nonce', 'nonce' );
    NEXORA_MARKET_CSV::output_template();
} );
